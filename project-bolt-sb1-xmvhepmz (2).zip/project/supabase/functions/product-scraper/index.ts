import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js@2.39.7';
import * as cheerio from 'npm:cheerio@1.0.0-rc.12';
import axios from 'npm:axios@1.6.7';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    );

    const { data: products, error } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);

    if (error) throw error;

    for (const product of products) {
      const updatedPrices = await Promise.all([
        fetchAmazonPrice(product.links.amazon),
        fetchFlipkartPrice(product.links.flipkart),
        fetchMyntraPrice(product.links.myntra),
      ]);

      const [amazonPrice, flipkartPrice, myntraPrice] = updatedPrices;

      await supabase
        .from('products')
        .update({
          amazon_price: amazonPrice || product.amazon_price,
          flipkart_price: flipkartPrice || product.flipkart_price,
          myntra_price: myntraPrice || product.myntra_price,
          last_updated: new Date().toISOString(),
        })
        .eq('id', product.id);

      // Add to price history
      if (amazonPrice || flipkartPrice || myntraPrice) {
        const priceHistory = [];
        if (amazonPrice) {
          priceHistory.push({
            product_id: product.id,
            platform: 'amazon',
            price: amazonPrice,
          });
        }
        if (flipkartPrice) {
          priceHistory.push({
            product_id: product.id,
            platform: 'flipkart',
            price: flipkartPrice,
          });
        }
        if (myntraPrice) {
          priceHistory.push({
            product_id: product.id,
            platform: 'myntra',
            price: myntraPrice,
          });
        }

        await supabase.from('price_history').insert(priceHistory);
      }
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function fetchAmazonPrice(url: string): Promise<number | null> {
  if (!url) return null;
  try {
    const response = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    const $ = cheerio.load(response.data);
    const priceText = $('.a-price-whole').first().text().replace(/[^0-9]/g, '');
    return priceText ? parseFloat(priceText) : null;
  } catch (error) {
    console.error('Error fetching Amazon price:', error);
    return null;
  }
}

async function fetchFlipkartPrice(url: string): Promise<number | null> {
  if (!url) return null;
  try {
    const response = await axios.get(url);
    const $ = cheerio.load(response.data);
    const priceText = $('._30jeq3._16Jk6d').first().text().replace(/[^0-9]/g, '');
    return priceText ? parseFloat(priceText) : null;
  } catch (error) {
    console.error('Error fetching Flipkart price:', error);
    return null;
  }
}

async function fetchMyntraPrice(url: string): Promise<number | null> {
  if (!url) return null;
  try {
    const response = await axios.get(url);
    const $ = cheerio.load(response.data);
    const priceText = $('.pdp-price strong').first().text().replace(/[^0-9]/g, '');
    return priceText ? parseFloat(priceText) : null;
  } catch (error) {
    console.error('Error fetching Myntra price:', error);
    return null;
  }
}