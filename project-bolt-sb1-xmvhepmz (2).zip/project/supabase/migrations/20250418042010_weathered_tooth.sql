/*
  # Fix cart items RLS policy

  1. Changes
    - Drop existing RLS policy that doesn't properly handle INSERT operations
    - Create new RLS policy that correctly handles all operations including INSERT
    
  2. Security
    - Ensures users can only manage their own cart items
    - Properly handles INSERT operations with with_check clause
*/

-- Drop the existing policy that doesn't handle INSERT properly
DROP POLICY IF EXISTS "Users can manage their cart items" ON cart_items;

-- Create new policy that properly handles all operations including INSERT
CREATE POLICY "Users can manage their cart items"
ON cart_items
FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);