/*
  # Add products with links

  1. Schema Changes
    - Add links column to products table (JSONB type)
  
  2. Data
    - Insert 40 sample products across categories
    - Add platform-specific links for each product
*/

-- Add links column to products table
ALTER TABLE products ADD COLUMN IF NOT EXISTS links JSONB DEFAULT '{}'::jsonb;

-- Insert sample products
INSERT INTO products (name, description, image_url, category, amazon_price, flipkart_price, myntra_price, last_updated)
VALUES
  -- Electronics
  ('Apple iPhone 13', '128GB, Midnight Blue, Advanced A15 Bionic chip', 'https://images.unsplash.com/photo-1632661674596-618d8c1d2cb4', 'Electronics', 69999, 71999, NULL, NOW()),
  ('Samsung Galaxy S21', '256GB, Phantom Black, 108MP Camera', 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf', 'Electronics', 54999, 52999, NULL, NOW()),
  ('Sony WH-1000XM4', 'Wireless Noise Cancelling Headphones', 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb', 'Electronics', 24999, 26999, NULL, NOW()),
  ('MacBook Air M1', '13-inch, 8GB RAM, 256GB SSD', 'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9', 'Electronics', 89999, 92999, NULL, NOW()),
  ('iPad Air', '10.9-inch, WiFi, 64GB', 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0', 'Electronics', 54999, 56999, NULL, NOW()),

  -- Fashion
  ('Nike Air Max', 'Running Shoes, Black', 'https://images.unsplash.com/photo-1542291026-7eec264c27ff', 'Fashion', NULL, 7999, 8499, NOW()),
  ('Levi''s 501', 'Original Fit Men''s Jeans', 'https://images.unsplash.com/photo-1542272604-787c3835535d', 'Fashion', 3999, 3499, 3799, NOW()),
  ('Ray-Ban Aviator', 'Classic Sunglasses', 'https://images.unsplash.com/photo-1572635196237-14b3f281503f', 'Fashion', 5999, 6299, 5899, NOW()),
  ('Casio G-Shock', 'Digital Watch', 'https://images.unsplash.com/photo-1523275335684-37898b6baf30', 'Fashion', 8999, 8499, 8799, NOW()),
  ('Adidas Ultraboost', 'Running Shoes', 'https://images.unsplash.com/photo-1556906781-9a412961c28c', 'Fashion', NULL, 12999, 13499, NOW()),

  -- Home & Kitchen
  ('Instant Pot Duo', 'Electric Pressure Cooker', 'https://images.unsplash.com/photo-1585664811087-47f65abbad64', 'Home & Kitchen', 7999, 7499, NULL, NOW()),
  ('Philips Air Fryer', 'Digital XL', 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5', 'Home & Kitchen', 12999, 11999, NULL, NOW()),
  ('Dyson V11', 'Cordless Vacuum Cleaner', 'https://images.unsplash.com/photo-1558317374-067fb5f30001', 'Home & Kitchen', 44999, 46999, NULL, NOW()),
  ('KitchenAid Mixer', 'Stand Mixer, Red', 'https://images.unsplash.com/photo-1594385208974-2e75f8d7bb48', 'Home & Kitchen', 32999, 34999, NULL, NOW()),
  ('Nespresso Vertuo', 'Coffee Maker', 'https://images.unsplash.com/photo-1517914245284-75db67af6c8f', 'Home & Kitchen', 15999, 16999, NULL, NOW()),

  -- Books
  ('Atomic Habits', 'James Clear', 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c', 'Books', 499, 449, NULL, NOW()),
  ('The Psychology of Money', 'Morgan Housel', 'https://images.unsplash.com/photo-1554774853-719586f82d77', 'Books', 399, 379, NULL, NOW()),
  ('Sapiens', 'Yuval Noah Harari', 'https://images.unsplash.com/photo-1589998059171-988d887df646', 'Books', 599, 549, NULL, NOW()),
  ('Think Like a Monk', 'Jay Shetty', 'https://images.unsplash.com/photo-1544947950-fa07a98d237f', 'Books', 449, 399, NULL, NOW()),
  ('The Alchemist', 'Paulo Coelho', 'https://images.unsplash.com/photo-1544947950-fa07a98d237f', 'Books', 299, 279, NULL, NOW()),

  -- More Electronics
  ('OnePlus 9 Pro', '256GB, Morning Mist', 'https://images.unsplash.com/photo-1614796740107-5b5aa0a0cb9b', 'Electronics', 49999, 47999, NULL, NOW()),
  ('Dell XPS 13', 'Intel i7, 16GB RAM', 'https://images.unsplash.com/photo-1593642632823-8f785ba67e45', 'Electronics', 129999, 127999, NULL, NOW()),
  ('Canon EOS R6', 'Mirrorless Camera', 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32', 'Electronics', 189999, 192999, NULL, NOW()),
  ('Nintendo Switch', 'OLED Model', 'https://images.unsplash.com/photo-1578303512597-81e6cc155b3e', 'Electronics', 29999, 31999, NULL, NOW()),
  ('LG OLED TV', '55-inch 4K Smart TV', 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1', 'Electronics', 149999, 147999, NULL, NOW()),

  -- More Fashion
  ('Tommy Hilfiger Shirt', 'Classic Fit', 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633', 'Fashion', 2999, 2799, 2899, NOW()),
  ('Michael Kors Watch', 'Analog', 'https://images.unsplash.com/photo-1524592094714-0f0654e20314', 'Fashion', 15999, 16499, 15799, NOW()),
  ('Calvin Klein Dress', 'Black Evening', 'https://images.unsplash.com/photo-1539008835657-9e8e9680c956', 'Fashion', NULL, 9999, 9499, NOW()),
  ('Puma Running Shoes', 'Hybrid', 'https://images.unsplash.com/photo-1542291026-7eec264c27ff', 'Fashion', 5999, 5499, 5799, NOW()),
  ('Fossil Wallet', 'Leather Bifold', 'https://images.unsplash.com/photo-1627123424574-724758594e93', 'Fashion', 2499, 2299, 2399, NOW()),

  -- More Home & Kitchen
  ('Samsung Microwave', 'Convection', 'https://images.unsplash.com/photo-1574269909862-7e1d70bb8078', 'Home & Kitchen', 14999, 13999, NULL, NOW()),
  ('Bosch Dishwasher', '14 Place Settings', 'https://images.unsplash.com/photo-1581622558663-b2ce33ba42f3', 'Home & Kitchen', 39999, 38999, NULL, NOW()),
  ('Havells Iron', 'Steam Iron', 'https://images.unsplash.com/photo-1592156328697-ee43a3ad2d97', 'Home & Kitchen', 1999, 1899, NULL, NOW()),
  ('Kent Water Purifier', 'RO + UV', 'https://images.unsplash.com/photo-1523362628745-0c100150b504', 'Home & Kitchen', 16999, 15999, NULL, NOW()),
  ('Prestige Induction', 'Cooktop', 'https://images.unsplash.com/photo-1522838573142-664c91c13f7a', 'Home & Kitchen', 3999, 3799, NULL, NOW()),

  -- More Books
  ('The Silent Patient', 'Alex Michaelides', 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c', 'Books', 399, 379, NULL, NOW()),
  ('Ikigai', 'Héctor García', 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c', 'Books', 449, 429, NULL, NOW()),
  ('Rich Dad Poor Dad', 'Robert Kiyosaki', 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c', 'Books', 399, 379, NULL, NOW()),
  ('The Power of Now', 'Eckhart Tolle', 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c', 'Books', 499, 479, NULL, NOW()),
  ('Think and Grow Rich', 'Napoleon Hill', 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c', 'Books', 349, 329, NULL, NOW());

-- Update product links
UPDATE products 
SET links = jsonb_build_object(
  'amazon', CASE 
    WHEN amazon_price IS NOT NULL 
    THEN concat('https://www.amazon.in/dp/', substr(md5(random()::text), 1, 10))
    ELSE NULL
  END,
  'flipkart', CASE 
    WHEN flipkart_price IS NOT NULL 
    THEN concat('https://www.flipkart.com/p/', substr(md5(random()::text), 1, 10))
    ELSE NULL
  END,
  'myntra', CASE 
    WHEN myntra_price IS NOT NULL 
    THEN concat('https://www.myntra.com/p/', substr(md5(random()::text), 1, 10))
    ELSE NULL
  END
);