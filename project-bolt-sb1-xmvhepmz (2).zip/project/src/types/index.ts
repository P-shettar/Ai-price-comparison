export interface User {
  id: string;
  email: string;
  created_at: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  image_url: string;
  category: string;
  amazon_price: number | null;
  flipkart_price: number | null;
  myntra_price: number | null;
  links: {
    amazon?: string;
    flipkart?: string;
    myntra?: string;
  };
  last_updated: string;
  created_at: string;
}

export interface CartItem {
  id: string;
  user_id: string;
  product_id: string;
  product: Product;
  quantity: number;
  created_at: string;
}