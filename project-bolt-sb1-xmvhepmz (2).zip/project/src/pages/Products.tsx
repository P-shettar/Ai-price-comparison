import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Product } from '../types';
import { ShoppingCart, Filter, TrendingDown, ExternalLink, RefreshCw } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { useNavigate } from 'react-router-dom';

const Products = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const { user } = useAuthStore();
  const navigate = useNavigate();

  useEffect(() => {
    fetchProducts();
    // Set up real-time subscription for price updates
    const subscription = supabase
      .channel('products_channel')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, () => {
        fetchProducts();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [selectedCategory, searchQuery]);

  const fetchProducts = async () => {
    try {
      let query = supabase
        .from('products')
        .select('*')
        .order('last_updated', { ascending: false });
      
      if (selectedCategory !== 'all') {
        query = query.eq('category', selectedCategory);
      }
      
      if (searchQuery) {
        query = query.ilike('name', `%${searchQuery}%`);
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      setProducts(data as Product[]);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const refreshPrices = async () => {
    setRefreshing(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/product-scraper`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
      });
      
      if (!response.ok) throw new Error('Failed to refresh prices');
      
      await fetchProducts();
    } catch (error) {
      console.error('Error refreshing prices:', error);
    } finally {
      setRefreshing(false);
    }
  };

  const getBestPrice = (product: Product) => {
    const prices = {
      amazon: product.amazon_price,
      flipkart: product.flipkart_price,
      myntra: product.myntra_price,
    };

    const validPrices = Object.entries(prices).filter(([_, price]) => price !== null);
    if (validPrices.length === 0) return null;
    
    return validPrices.reduce((best, current) => 
      current[1] < best[1] ? current : best
    );
  };

  const getPriceDifference = (bestPrice: number, currentPrice: number) => {
    if (!currentPrice) return null;
    const difference = currentPrice - bestPrice;
    const percentage = ((difference / bestPrice) * 100).toFixed(1);
    return `+₹${difference.toLocaleString()} (${percentage}% more)`;
  };

  const addToCart = async (productId: string) => {
    if (!user) {
      navigate('/signup');
      return;
    }

    try {
      const { error } = await supabase
        .from('cart_items')
        .insert([
          {
            user_id: user.id,
            product_id: productId,
            quantity: 1,
          },
        ]);

      if (error) throw error;
      alert('Product added to cart!');
    } catch (error) {
      console.error('Error adding to cart:', error);
      alert('Failed to add product to cart');
    }
  };

  const categories = ['all', 'Electronics', 'Fashion', 'Home & Kitchen', 'Books'];

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4">
      <div className="mb-8 flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="flex items-center gap-4">
          <Filter className="h-5 w-5 text-gray-500" />
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="border rounded-lg px-4 py-2"
          >
            {categories.map((category) => (
              <option key={category} value={category}>
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </option>
            ))}
          </select>
          
          <button
            onClick={refreshPrices}
            disabled={refreshing}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
              refreshing
                ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                : 'bg-blue-500 text-white hover:bg-blue-600'
            }`}
          >
            <RefreshCw className={`h-5 w-5 ${refreshing ? 'animate-spin' : ''}`} />
            {refreshing ? 'Refreshing...' : 'Refresh Prices'}
          </button>
        </div>
        
        <input
          type="text"
          placeholder="Search products..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="border rounded-lg px-4 py-2 w-full md:w-64"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {products.map((product) => {
          const bestPrice = getBestPrice(product);
          
          return (
            <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/3">
                  <img
                    src={product.image_url}
                    alt={product.name}
                    className="w-full h-48 md:h-full object-cover"
                  />
                </div>
                <div className="md:w-2/3 p-4">
                  <h3 className="text-lg font-semibold mb-2">{product.name}</h3>
                  <p className="text-gray-600 mb-4 text-sm">{product.description}</p>
                  
                  <div className="space-y-3 mb-4">
                    {bestPrice && (
                      <div className="flex items-center gap-2 text-green-600 font-semibold">
                        <TrendingDown className="h-5 w-5" />
                        <span>Best Price: ₹{bestPrice[1].toLocaleString()} on {bestPrice[0]}</span>
                      </div>
                    )}
                    
                    <div className="border rounded-lg overflow-hidden">
                      <table className="w-full text-sm">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-4 py-2 text-left">Platform</th>
                            <th className="px-4 py-2 text-left">Price</th>
                            <th className="px-4 py-2 text-left">Difference</th>
                            <th className="px-4 py-2 text-left">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {product.amazon_price && (
                            <tr>
                              <td className="px-4 py-2">Amazon</td>
                              <td className="px-4 py-2">₹{product.amazon_price.toLocaleString()}</td>
                              <td className="px-4 py-2 text-gray-500">
                                {bestPrice && bestPrice[1] !== product.amazon_price
                                  ? getPriceDifference(bestPrice[1], product.amazon_price)
                                  : '-'
                                }
                              </td>
                              <td className="px-4 py-2">
                                <a
                                  href={product.links.amazon}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-blue-500 hover:text-blue-600"
                                >
                                  <ExternalLink className="h-4 w-4" />
                                </a>
                              </td>
                            </tr>
                          )}
                          {product.flipkart_price && (
                            <tr>
                              <td className="px-4 py-2">Flipkart</td>
                              <td className="px-4 py-2">₹{product.flipkart_price.toLocaleString()}</td>
                              <td className="px-4 py-2 text-gray-500">
                                {bestPrice && bestPrice[1] !== product.flipkart_price
                                  ? getPriceDifference(bestPrice[1], product.flipkart_price)
                                  : '-'
                                }
                              </td>
                              <td className="px-4 py-2">
                                <a
                                  href={product.links.flipkart}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-blue-500 hover:text-blue-600"
                                >
                                  <ExternalLink className="h-4 w-4" />
                                </a>
                              </td>
                            </tr>
                          )}
                          {product.myntra_price && (
                            <tr>
                              <td className="px-4 py-2">Myntra</td>
                              <td className="px-4 py-2">₹{product.myntra_price.toLocaleString()}</td>
                              <td className="px-4 py-2 text-gray-500">
                                {bestPrice && bestPrice[1] !== product.myntra_price
                                  ? getPriceDifference(bestPrice[1], product.myntra_price)
                                  : '-'
                                }
                              </td>
                              <td className="px-4 py-2">
                                <a
                                  href={product.links.myntra}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-blue-500 hover:text-blue-600"
                                >
                                  <ExternalLink className="h-4 w-4" />
                                </a>
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <button
                    onClick={() => addToCart(product.id)}
                    className="w-full flex items-center justify-center gap-2 bg-gray-100 text-gray-700 px-4 py-2 rounded hover:bg-gray-200 transition-colors"
                  >
                    <ShoppingCart className="h-5 w-5" />
                    {user ? 'Add to Cart' : 'Sign Up to Add to Cart'}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Products;