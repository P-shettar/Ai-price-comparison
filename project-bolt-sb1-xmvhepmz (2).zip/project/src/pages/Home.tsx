import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, TrendingUp, ShoppingBag } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

const Home = () => {
  const { user } = useAuthStore();
  const navigate = useNavigate();

  const handleStartShopping = () => {
    if (!user) {
      navigate('/signup');
    } else {
      navigate('/products');
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold mb-4">
          Find the Best Deals Across Multiple Platforms
        </h1>
        <p className="text-xl text-gray-600">
          Compare prices from Amazon, Flipkart, Myntra, and Ajio in one place
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        <div className="bg-white p-6 rounded-lg shadow-md transform hover:scale-105 transition-transform">
          <Search className="h-12 w-12 text-blue-500 mb-4" />
          <h3 className="text-xl font-semibold mb-2">Compare Prices</h3>
          <p className="text-gray-600">
            Find the best deals across multiple e-commerce platforms instantly
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md transform hover:scale-105 transition-transform">
          <TrendingUp className="h-12 w-12 text-blue-500 mb-4" />
          <h3 className="text-xl font-semibold mb-2">Price Predictions</h3>
          <p className="text-gray-600">
            AI-powered price predictions to help you make informed decisions
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md transform hover:scale-105 transition-transform">
          <ShoppingBag className="h-12 w-12 text-blue-500 mb-4" />
          <h3 className="text-xl font-semibold mb-2">Save Money</h3>
          <p className="text-gray-600">
            Get the best value for your money with our price comparison
          </p>
        </div>
      </div>

      <div className="text-center">
        <button
          onClick={handleStartShopping}
          className="bg-blue-500 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-600 transform hover:scale-105 transition-all"
        >
          Start Shopping
        </button>
      </div>
    </div>
  );
};

export default Home;